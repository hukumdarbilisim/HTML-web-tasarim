$(document).ready(function () {

    $('#slider.owl-carousel').owlCarousel({
        loop:true,
        center: true,
        margin:0,
        dots:false,
        nav:false,
        autoplay:true,
        autoplayTimeout:5000,
        navText:['<i class="fa fa-angle-left font-size-100 font-dark wow fadeInLeft left" aria-hidden="true"></i>','<i class="fa fa-angle-right font-size-100 font-dark wow fadeInRight right" aria-hidden="true"></i>'],
        responsive:{
            0:{
            items:1
            },
            576:{
                items:1
            },
            768:{
                items:1
            },
            992:{
                items:1
            },
            1200:{
                items:1
            }
        }
    });
    
    $('.grid').masonry({
        itemSelector: '.grid-item',
        columnWidth: '.col-4',
        percentPosition: true
    });
        
    
});