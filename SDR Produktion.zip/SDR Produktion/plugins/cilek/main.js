$(document).ready(function () {
    
    // Ekran ve Gövde Boyutları Ölçüleri
    
    var windowWidth     = $(window).width();
    var windowHeight    = $(window).outerHeight();
    var bodyWidth       = $('body').width();
    var bodyHeight      = $('body').outerHeight();
    $(window).resize(function(){
        var windowWidth     = $(window).width();
        var windowHeight    = $(window).outerHeight();
        var bodyWidth       = $('body').width();
        var bodyHeight      = $('body').outerHeight();
    });
    
   
    // Tree
    
    $('.tree').each(function(){
        $(this).find('.wood-leaf').click(function(){
            $(this).parent('span').parent('.tree-branch').parent('li').children('ul').toggle();
            $(this).children('i').toggleClass('fa-chevron-up', 'add');
            $(this).children('i').toggleClass('fa-chevron-down', 'remove');
            return false;
        });
    });
    
    // Butonlar
    
    $('.btn-group .btn-dropdown-group>.btn').append( "<i class='fa fa-angle-down margin-left-7'></i>" );
    $('.btn-group .btn-dropdown-group .btn').click(function(){
        if ($(this).hasClass('btn-dropdown-right')) {
            $(this).toggleClass('border-bottom-left-radius-0');
            $(this).parent('.btn-dropdown-group').children('.btn-dropdown').toggle();
        } else {
            $(this).toggleClass('border-bottom-right-radius-0');
            $(this).parent('.btn-dropdown-group').children('.btn-dropdown').toggle();
        }        
        return false;
    });
    
        // Checkbox İçin Butonlar
    
        $('label.checkbox').each(function(){
            var btn             = $(this).attr('data-btn');
            var btnActive       = $(this).attr('data-active-btn');
            var btnIcon         = $(this).attr('data-btn-icon');
            var btnActiveIcon   = $(this).attr('data-active-btn-icon');
            $(this).addClass(btn);
            $(this).children('i').addClass(btnIcon);
            $(this).click(function(){
                $(this).toggleClass(btn);
                $(this).toggleClass(btnActive);
                $(this).children('i').toggleClass(btnActiveIcon);
                $(this).children('i').toggleClass(btnIcon);
            });
        });
    
    // Sticky - Sabit Footer
    
    if( bodyHeight <= windowHeight ) {
        $('footer#sticky').addClass('footer-fixed-bottom');
    }
    
     // Animasyon
    
    var wow = new WOW(
      {
        boxClass:     'wow',     
        animateClass: 'animated', 
        offset:       10,          
        mobile:       true,       
        live:         true,       
        callback:     function(box) {
        },
        scrollContainer: null
      }
    );
    wow.init();
    
    $('.h-animated').each(function(){
        $(this).hover(function(){
            $(this).addClass('animated');
        },function(){
            $(this).removeClass('animated');
        });
    });
    
    // Widgetlar
        
        // Aside Nav
    
        $('.widget-nav ul ul').hide();
        $('.widget-nav ul ul li a.active').parent('li').parent('ul').show();
        $('.widget-nav ul ul').addClass('bg bg-white opacity-30');
        $('.widget-nav ul ul').parent('li').children('a').append('<i class="pull-right margin-top-3 fa fa-angle-down" aria-hidden="true"></i>');
        $('.widget-nav ul ul').parent('li').children('a').click(function(){
            $(this).parent('li').children('ul').toggle(300);
            return false;
        });
    
    // Yukarı Çık
    
    $('#go-top').click(function(){
        $('html, body').animate({
			scrollTop: 0 }, 800
		);
        return false;
    });
    
    // İçeriğe Git
    
    $('#go-content').click(function(){
        var $contentPosition = $(this).parent('section');
        var contentStart = $contentPosition.position().top + $contentPosition.outerHeight();
        $('html, body').animate({
			scrollTop: contentStart }, 800
		);
        return false;
    });
    
    // Ad Slide
    
    var adSlideImg = $('#ad-slide .item:first-child img').attr('src');
    $('#ad-slide .big-img').attr('src', adSlideImg);
    $('#ad-slide .item img').click(function(){
        var newImgUrl = $(this).attr('src');
        $('#ad-slide .big-img').attr('src', newImgUrl);
    });
        
    // Disable Button
    
    $('.btn-disable').click(function(){
        return false;
    });
    
    // Header Nav 
    
    $('nav#header-nav ul.nav>li>ul').parent('li').children('a').append('<i class="fa fa-angle-down font-size-10 margin-left-7" aria-hidden="true"></i>');
    
    
    // Mobile Menu
    
        $('#mobile-button a').click(function(){
            $('#mobile-nav').toggle(300);
            $('#mobile-menu .pull-right').removeClass('pull-right')
            $('#mobile-menu .hidden').removeClass('hidden')
            $('#mobile-menu .bg').removeClass('bg-secondary bg-hover-primary')
            $('#mobile-menu .bg').addClass('bg-primary bg-hover-white font-hover-primary')
            return false;
        });
    
        $('#mobile-nav a.close-mobile-nav').click(function(){
            $('#mobile-nav').hide(300);
            return false;
        });
    
        $('nav#header-nav ul.nav').clone().appendTo('#mobile-menu');
        $('#mobile-menu ul, #mobile-menu ul li, #mobile-menu ul a').removeClass();
    
        $('#mobile-menu ul ul').parent('li').children('a').click(function(){
            $(this).parent('li').children('ul').toggle();
            var ulStatus = $(this).parent('li').children('ul').css('display');
            if (ulStatus == 'block') {
                $(this).addClass('bg bg-primary');
                $(this).parent('li').children('ul').addClass('bg bg-primary opacity-70');
            } else {
                $(this).removeClass('bg bg-primary');
                $(this).parent('li').children('ul').addClass('bg bg-primary opacity-70');
            }
            return false;
        });

    
    // Magnific Popup
    
    // $('.gallery').each(function() { 
    //     $(this).magnificPopup({
    //         delegate: 'a',
    //         type: 'image',
    //         gallery: {
    //           enabled:true
    //         }
    //     });
    // });
    
    //$('.popup-youtube, .popup-vimeo, .popup-gmaps, .popup-iframe').magnificPopup({
    //    disableOn: 900,
    //    type: 'iframe',
    //    mainClass: 'mfp-fade',
    //    removalDelay: 160,
    //    preloader: false,

    //    fixedContentPos: false
    //});
    
    //$('.open-popup').magnificPopup({
    //    type:'inline',
    //    midClick: true
    //});
    
    
    // Takvim
    
    //$('#calendar').fullCalendar({
    //    contentHeight: 1000,
    //    customButtons: {
    //        myCustomButton: {
    //            text: 'Tarih Ekle',
    //            click: function() {
    //                alert('clicked the custom button!');
    //            }
    //        }
    //    },
    //    header: {
    //        left: 'prev,next today myCustomButton',
    //        center: 'title',
    //        right: 'month,agendaWeek,agendaDay'
    //    },
    //});
    
});